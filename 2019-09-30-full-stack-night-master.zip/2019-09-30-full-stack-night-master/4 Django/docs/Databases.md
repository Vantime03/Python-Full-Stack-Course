



## SQL Injection

SQL injection is a common method of attacking and exploiting a web application. One can write parts of SQL statements inside input fields, and when the back-end concatenates the values together to produce a SQL statement, it includes the values that the user entered, allowing a user to execute arbitrary SQL on the database. This can give them access to sensitive information. You can read more about SQL injection on [w3schools](https://www.w3schools.com/sql/sql_injection.asp) and [wikipedia](https://en.wikipedia.org/wiki/SQL_injection). [Bobby Tables](https://www.explainxkcd.com/wiki/index.php/327:_Exploits_of_a_Mom)
