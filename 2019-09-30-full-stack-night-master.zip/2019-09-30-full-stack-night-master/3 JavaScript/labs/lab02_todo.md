
# Lab 2: Todo List

Let's make a simple todo-list which supports the following operations:

- add an item to the list
- remove an item from the list
- mark an item as completed

Removed items should disappear entirely. Completed items should appear at the bottom (or in a separate list) with a line through them.


