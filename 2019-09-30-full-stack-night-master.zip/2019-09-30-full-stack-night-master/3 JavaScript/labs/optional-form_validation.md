


# Lab: Form Validation

Let's make a form for validating user input using regular expressions. Note that there are looser or stricter ways of writing regular expressions for validating these. The more strict, the better.

- Username: at least 6 characters long
- Password: at least 6 characters long
- First+Last Name: one or more letters, space, one or more letters
- Email Address: one or more numbers/letters, @, one or more numbers/letters, ., one or more numbers/letters
- Phone Number: e.g. 293-213-5555
- Date of Birth: e.g. 2/13/2627
- Social Security Number: e.g. 415-25-2627
