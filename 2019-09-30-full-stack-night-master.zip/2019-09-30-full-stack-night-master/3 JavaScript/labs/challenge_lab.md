# Challenge lab: Calculator

Using the calculator interface we've built up, add the functionality using vanilla JavaScript.