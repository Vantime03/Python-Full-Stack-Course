


# Lab1: Python Pain Redux

From the Python labs, redo Pick6, rot13, and the unit converter assignments in JavaScript. You should first try to write them using JavaScript's `prompt` and `alert` in place of Python's `input` and `print`. Once you have that working, use `input` and `button` elements, with events. You can read the docs on [DOM Manipulation](../docs/09%20-%20DOM%20Manipulation.md) and [Events](../docs/10%20-%20Events.md). You can view a demo [here](https://codepen.io/flux2341/pen/rJpBXe?editors=1010).





