# lab4: conceptual
1. explain what hoisting is
2. given the following code: 
   ```javascript
   ```
   what will be the result?
3. what is the difference between var, let, and const?
4. given the following declaration in javascript:
    ```javascript
    const an_array = [1, 2, 3, 4, 5, 6];
    ```
    is the following operation legal? if it is, what will be the result?
    ```javascript
    an_array = [2, 4, 6, 8, 10, 12];
    ```

5. given the following declaration in javascript:
    ```javascript
    const an_array = [1, 2, 3, 4, 5, 6];
    ```
    is the following operation legal? if it is, what will be the result?
    ```javascript
    an_array[0] = an_array[length(an_array)]
    ```

 1. given the following declaration in javascript:
    ```javascript
    const x = 5;
    ```
    is the following operation legal? if it is, what will be the result?
    ```javascript
    x = 7;
    ```