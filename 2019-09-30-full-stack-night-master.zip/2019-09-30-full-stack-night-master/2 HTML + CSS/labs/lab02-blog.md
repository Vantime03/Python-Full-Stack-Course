

# Lab 2: Blog

Let's make the template of a blog with a title, top-nav and multiple posts. Use the [semantic elements](https://www.w3schools.com/html/html5_semantic_elements.asp) header, nav, section, and footer. You can make generate fake content using [Lorem Ipsum](https://www.lipsum.com/). 

Feel free to use a [CSS Framework](../docs/03%20-%20CSS%20Overview.md#css-frameworks). You may also want to use [flexbox](https://css-tricks.com/snippets/css/a-guide-to-flexbox/) or [grid](https://css-tricks.com/snippets/css/complete-guide-grid/), and apply [responsive design](../docs/09%20-%20CSS%20Responsive%20Design.md).
