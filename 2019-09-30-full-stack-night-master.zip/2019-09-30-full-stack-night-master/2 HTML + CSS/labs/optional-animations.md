# Exercise: Recreate animations in CSS

## Objective
Recreate animations in CSS

- Go to [this pen](https://codepen.io/Chelsea-Dover/pen/rzOyaY?editors=1100) and fork it (the 'fork' button is in the top right corner).
- Go [here](https://codepen.io/Chelsea-Dover/full/ygNwej/) and in your pen match the animations. You don't have to worry about the colors being different. Just focus on the effects.

**bonus points**

- Go to [this pen](https://codepen.io/Chelsea-Dover/pen/EmOGep) and fork it (the 'fork' button is in the top right corner).
- Either play around with your pen and make your very own animations **or** go [here](https://codepen.io/Chelsea-Dover/pen/EmOGep?editors=1100) and in your pen match the animations.