

# Lab 3: Company Home

Pick an industry and create the landing page for a hypothetical company, filling in as much detail as possible. Use one of the CSS Frameworks listed [here](../docs/03%20-%20CSS%20Overview.md#css-frameworks) and make sure it's responsive. Use this reference [image](sidebar.jpeg), and browse the internet for existing company pages and imitate as much as you can.
