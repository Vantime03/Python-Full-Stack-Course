

# Lab 4: Personal Portfolio

Did you know GitHub will let you use a repo to host a static website? Follow [this tutorial](https://pages.github.com/) to create your own site. This will be a separate repo from your class repo, but do not place your other labs here.

If you're looking for inspiration, check out these:
- http://matthewbryancurtis.com/
- https://kprasch.github.io/TinyResume/
- https://medium.freecodecamp.org/15-web-developer-portfolios-to-inspire-you-137fb1743cae
- https://www.reddit.com/r/learnprogramming/comments/39g7v9/example_portfolio_websites/

