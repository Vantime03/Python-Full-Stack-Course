from django.apps import AppConfig


class BurritoApiConfig(AppConfig):
    name = 'burrito_api'
