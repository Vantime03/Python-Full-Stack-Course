


# Deployment

## Python Anywhere

[video guide](https://www.youtube.com/watch?v=Y4c4ickks2A)