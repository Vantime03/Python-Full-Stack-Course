
# Crime Data

Open one of the crime data csv's in the data folder, and derive the following statistics.

- The specific most common crime type.
- The rarest crimes.
- The year with the most crime.