# .META Guidebook

The `.meta` folder is place for non documentation specific tools and helpers, this is the place to write or source code for managing our wonderful class repository!

## Meta's current contents

As of April 1st 2018, `.meta` is home to simply a todo list parser that checks for documentation!

More to come soon.

## Getting it running

* Create a virtual environment
* Install the requirements from `requirements.txt` with `pip install -r requirements.txt`
* Run `python -m test_runner` to get coverage!
