#!/usr/bin/bash

cloc . -exclude-dir=__pycache__ -exclude-dir=env
